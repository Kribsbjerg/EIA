﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassesForProjectEIA
{
    class VisitationConsiderations
    {
        #region Private Members

        private DateTime _treatmentDay;

        #endregion

        #region Constructors 

        public VisitationConsiderations()

        #endregion

        #region Public Properties


        #endregion

    }
}
