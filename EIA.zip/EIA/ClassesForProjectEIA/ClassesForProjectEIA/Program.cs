﻿using System;

namespace ClassesForProjectEIA
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.ReadLine();
        }
    }
}
