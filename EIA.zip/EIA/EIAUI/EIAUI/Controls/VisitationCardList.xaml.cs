﻿using System.Windows.Controls;

namespace EIAUI
{
    /// <summary>
    /// Interaction logic for VisitationCardList.xaml
    /// </summary>
    public partial class VisitationCardList : UserControl
    {
        public VisitationCardList()
        {
            InitializeComponent();
        }
    }
}
